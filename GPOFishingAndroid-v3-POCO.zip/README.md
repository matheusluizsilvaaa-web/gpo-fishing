# GPO Fishing Android v0.3

Architecture
- CaptureService: MediaProjection screen capture (foreground service) + scanner + controller.
- FishingAccessibilityService: touch only (hold/release using GestureDescription.StrokeDescription.continueStroke()).
- TrackController: deadband 2.0, k_v 0.12, lead_sec 0.08, velocity_smooth 0.65.
- FishingScanner: blue (85,170,255), white (255,255,255), gray (25,25,25).

Build: push the project to a GitHub repo; the workflow in .github/workflows/build-apk.yml builds the APK
and attaches it to a Release. No PC needed.

Known assumptions: how k_v combines with lead_sec, and the scanner layout logic, are NOT recovered
from the original exe; tune on the device.
