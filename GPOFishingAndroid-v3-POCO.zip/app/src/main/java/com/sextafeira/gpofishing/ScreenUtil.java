package com.sextafeira.gpofishing;

import android.content.Context;
import android.hardware.display.DisplayManager;
import android.util.DisplayMetrics;
import android.view.Display;

/** Real screen size (current rotation), never hard-coded. */
final class ScreenUtil {
    private ScreenUtil() {}

    /** @return {widthPx, heightPx, densityDpi} of the default display right now. */
    @SuppressWarnings("deprecation")
    static int[] realMetrics(Context c) {
        DisplayManager dm = (DisplayManager) c.getSystemService(Context.DISPLAY_SERVICE);
        Display d = dm.getDisplay(Display.DEFAULT_DISPLAY);
        DisplayMetrics m = new DisplayMetrics();
        d.getRealMetrics(m);
        return new int[]{m.widthPixels, m.heightPixels, m.densityDpi};
    }
}
