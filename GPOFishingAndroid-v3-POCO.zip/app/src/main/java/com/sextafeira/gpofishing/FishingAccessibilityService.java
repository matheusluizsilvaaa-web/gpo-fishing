package com.sextafeira.gpofishing;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.accessibilityservice.GestureDescription.StrokeDescription;
import android.content.SharedPreferences;
import android.graphics.Path;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.accessibility.AccessibilityEvent;

/**
 * Only job: keep a finger pressed (hold) or lift it (release).
 *
 * A single gesture cannot last forever (max 60 s), so the hold is built as a
 * chain of short strokes: the first one is created with willContinue=true and
 * every next piece comes from continueStroke(). To release, the last piece is
 * created with willContinue=false, which lifts the finger.
 */
public class FishingAccessibilityService extends AccessibilityService {
    private static final String TAG = "GPOFishing";
    /** Length of each piece of the hold. Also the worst-case release delay. */
    private static final long CHUNK_MS = 100;

    public static final String PREFS = "cfg";
    public static final String KEY_X = "touchX";
    public static final String KEY_Y = "touchY";
    public static final float DEFAULT_X = 0.65f;
    public static final float DEFAULT_Y = 0.50f;

    private static volatile FishingAccessibilityService instance;

    private final Handler main = new Handler(Looper.getMainLooper());

    // All fields below are touched only on the main thread.
    private boolean touching = false;   // finger is logically down
    private boolean inFlight = false;   // a gesture is being dispatched
    private boolean wantHold = false;
    private StrokeDescription lastStroke;
    private float tx, ty;

    public static boolean isConnected() { return instance != null; }

    /** Thread-safe. true = keep finger down, false = lift it. */
    public static void setHold(final boolean want) {
        final FishingAccessibilityService s = instance;
        if (s == null) return;
        s.main.post(new Runnable() { @Override public void run() { s.applyHold(want); } });
    }

    /** Touch point in pixels for the current screen (null if service is off). */
    public static int[] currentTouchPoint() {
        FishingAccessibilityService s = instance;
        if (s == null) return null;
        int[] m = ScreenUtil.realMetrics(s);
        SharedPreferences p = s.getSharedPreferences(PREFS, MODE_PRIVATE);
        return new int[]{
                Math.round(m[0] * p.getFloat(KEY_X, DEFAULT_X)),
                Math.round(m[1] * p.getFloat(KEY_Y, DEFAULT_Y))};
    }

    @Override protected void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
        Log.i(TAG, "accessibility service connected");
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent e) { }

    @Override public void onInterrupt() {
        wantHold = false;
        touching = false;
        inFlight = false;
        lastStroke = null;
    }

    @Override public boolean onUnbind(android.content.Intent intent) {
        instance = null;
        return super.onUnbind(intent);
    }

    @Override public void onDestroy() {
        instance = null;
        super.onDestroy();
    }

    // ---------------------------------------------------------------- hold logic

    private void applyHold(boolean want) {
        wantHold = want;
        if (want) {
            if (!touching && !inFlight) startTouch();
        } else {
            if (touching && !inFlight) finishTouch();
            // if a piece is in flight, onCompleted() will see wantHold=false and finish.
        }
    }

    private Path point() {
        Path p = new Path();
        p.moveTo(tx, ty);
        return p;
    }

    private void startTouch() {
        int[] m = ScreenUtil.realMetrics(this);
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        tx = clamp(m[0] * prefs.getFloat(KEY_X, DEFAULT_X), 1, m[0] - 2);
        ty = clamp(m[1] * prefs.getFloat(KEY_Y, DEFAULT_Y), 1, m[1] - 2);
        StrokeDescription s = new StrokeDescription(point(), 0, CHUNK_MS, true);
        if (send(s)) {
            lastStroke = s;
            touching = true;
        }
    }

    private void continueTouch() {
        StrokeDescription next = lastStroke.continueStroke(point(), 0, CHUNK_MS, true);
        if (send(next)) {
            lastStroke = next;
        } else {
            touching = false;
            lastStroke = null;
        }
    }

    /** Sends the last piece (willContinue=false): this lifts the finger. */
    private void finishTouch() {
        StrokeDescription end = lastStroke.continueStroke(point(), 0, 1, false);
        send(end);
        touching = false;
        lastStroke = null;
    }

    private boolean send(StrokeDescription s) {
        GestureDescription g = new GestureDescription.Builder().addStroke(s).build();
        inFlight = true;
        boolean ok;
        try {
            ok = dispatchGesture(g, callback, main);
        } catch (RuntimeException e) {
            Log.e(TAG, "dispatchGesture", e);
            ok = false;
        }
        if (!ok) inFlight = false;
        return ok;
    }

    private final GestureResultCallback callback = new GestureResultCallback() {
        @Override public void onCompleted(GestureDescription g) {
            inFlight = false;
            if (touching) {
                if (wantHold) continueTouch(); else finishTouch();
            } else if (wantHold) {
                startTouch(); // a release just ended and a new hold was requested meanwhile
            }
        }

        @Override public void onCancelled(GestureDescription g) {
            inFlight = false;
            touching = false;
            lastStroke = null;
            if (wantHold) {
                main.postDelayed(new Runnable() {
                    @Override public void run() { if (wantHold) applyHold(true); }
                }, 50);
            }
        }
    };

    private static float clamp(float v, float lo, float hi) { return Math.max(lo, Math.min(hi, v)); }
}
