package com.sextafeira.gpofishing;

/**
 * Predictive controller. Parameters recovered from the original executable:
 * deadband = 2.0, k_v = 0.12, lead_sec = 0.08, velocity_smooth = 0.65.
 *
 * Returns true  = hold touch (bar accelerates upward)
 *         false = release   (bar accelerates downward)
 *
 * Coordinates are screen pixels, y grows downward.
 *
 * ASSUMPTION (not recovered from the original): how k_v is combined with
 * lead_sec. Here lead_sec projects the bar center forward in time and k_v is
 * a velocity damping term applied on top of that error. If the macro feels
 * too aggressive/lazy on the device, this is the line to revisit (see "u").
 */
public final class TrackController {
    public static final double DEADBAND = 2.0;
    public static final double K_V = 0.12;
    public static final double LEAD_SEC = 0.08;
    public static final double VELOCITY_SMOOTH = 0.65;

    /** Frames closer together than this are ignored (velocity would be pure noise). */
    private static final double MIN_DT = 0.008;
    /** A gap longer than this means the history is stale. */
    private static final double MAX_DT = 0.5;

    private boolean holding = false;
    private boolean hasPrev = false;
    private double prevCenter = 0, prevTime = 0, velocity = 0;

    /** Forget everything (call when the minigame disappears or the macro stops). */
    public void reset() {
        holding = false;
        hasPrev = false;
        prevCenter = 0;
        prevTime = 0;
        velocity = 0;
    }

    public double getVelocity() { return velocity; }

    /**
     * @param grayTop    top pixel row of the gray bar
     * @param grayBottom bottom pixel row of the gray bar
     * @param whiteY     pixel row of the white target
     * @param now        time in seconds (monotonic)
     */
    public boolean update(int grayTop, int grayBottom, int whiteY, double now) {
        double center = (grayTop + grayBottom) * 0.5;

        if (!hasPrev || (now - prevTime) > MAX_DT) {
            velocity = 0;
            prevCenter = center;
            prevTime = now;
            hasPrev = true;
        } else {
            double dt = now - prevTime;
            if (dt < MIN_DT) return holding;
            double rawV = (center - prevCenter) / dt;
            velocity = VELOCITY_SMOOTH * velocity + (1.0 - VELOCITY_SMOOTH) * rawV;
            prevCenter = center;
            prevTime = now;
        }

        double predicted = center + velocity * LEAD_SEC;
        double error = whiteY - predicted;
        // Moving up (negative velocity) => push the decision toward "release".
        double u = error - K_V * velocity;

        if (u < -DEADBAND) holding = true;       // target is above -> hold
        else if (u > DEADBAND) holding = false;  // target is below -> release
        return holding;                          // inside deadband: keep state
    }
}
