package com.sextafeira.gpofishing;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.widget.*;

public class MainActivity extends Activity {
    private static final int REQ_CAPTURE = 100;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private TextView status, xLabel, yLabel;
    private SharedPreferences prefs;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences(FishingAccessibilityService.PREFS, MODE_PRIVATE);

        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(30, 40, 30, 30);

        TextView t = new TextView(this);
        t.setText("GPO Fishing Android v0.3");
        t.setTextSize(23);
        l.addView(t);

        status = new TextView(this);
        status.setTextSize(14);
        status.setPadding(0, 20, 0, 20);
        l.addView(status);

        l.addView(button("1) Abrir Acessibilidade", v ->
                startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))));
        l.addView(button("Liberar \"configurações restritas\" (info do app)", v -> {
            Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
            i.setData(Uri.parse("package:" + getPackageName()));
            startActivity(i);
        }));
        l.addView(button("2) Iniciar captura de tela", v -> {
            MediaProjectionManager m =
                    (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
            startActivityForResult(m.createScreenCaptureIntent(), REQ_CAPTURE);
        }));
        l.addView(button("3) Ligar / desligar macro", v -> {
            if (!CaptureService.running) {
                Toast.makeText(this, "Inicie a captura primeiro", Toast.LENGTH_SHORT).show();
            } else if (!FishingAccessibilityService.isConnected()) {
                Toast.makeText(this, "Ative o serviço de acessibilidade", Toast.LENGTH_SHORT).show();
            } else {
                CaptureService.setMacro(!CaptureService.macroOn);
            }
        }));
        l.addView(button("Parar captura", v -> {
            Intent i = new Intent(this, CaptureService.class);
            i.setAction(CaptureService.ACTION_STOP);
            startService(i);
        }));

        xLabel = new TextView(this);
        l.addView(xLabel);
        l.addView(seek(FishingAccessibilityService.KEY_X, FishingAccessibilityService.DEFAULT_X, true));
        yLabel = new TextView(this);
        l.addView(yLabel);
        l.addView(seek(FishingAccessibilityService.KEY_Y, FishingAccessibilityService.DEFAULT_Y, false));

        ScrollView sv = new ScrollView(this);
        sv.addView(l);
        setContentView(sv);

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
        }
    }

    private Button button(String text, android.view.View.OnClickListener c) {
        Button bt = new Button(this);
        bt.setText(text);
        bt.setOnClickListener(c);
        return bt;
    }

    private SeekBar seek(final String key, float def, final boolean isX) {
        SeekBar s = new SeekBar(this);
        s.setMax(100);
        int v = Math.round(prefs.getFloat(key, def) * 100);
        s.setProgress(v);
        label(isX, v);
        s.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar sb, int p, boolean fromUser) {
                prefs.edit().putFloat(key, p / 100f).apply();
                label(isX, p);
            }
            @Override public void onStartTrackingTouch(SeekBar sb) { }
            @Override public void onStopTrackingTouch(SeekBar sb) { }
        });
        return s;
    }

    private void label(boolean isX, int p) {
        if (isX) xLabel.setText("Ponto do toque - horizontal: " + p + "%");
        else yLabel.setText("Ponto do toque - vertical: " + p + "%");
    }

    @Override protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_CAPTURE) {
            if (res == RESULT_OK && data != null) {
                Intent i = new Intent(this, CaptureService.class);
                i.setAction(CaptureService.ACTION_START);
                i.putExtra(CaptureService.EXTRA_CODE, res);
                i.putExtra(CaptureService.EXTRA_DATA, data);
                startForegroundService(i);
            } else {
                Toast.makeText(this, "Captura não autorizada", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private final Runnable refresh = new Runnable() {
        @Override public void run() {
            StringBuilder s = new StringBuilder();
            s.append("Acessibilidade: ")
                    .append(FishingAccessibilityService.isConnected() ? "ATIVA" : "INATIVA").append('\n');
            s.append("Captura: ");
            if (CaptureService.running) {
                s.append("ATIVA ").append(CaptureService.frameW).append('x')
                        .append(CaptureService.frameH).append(" @ ")
                        .append(CaptureService.fps).append(" fps");
            } else s.append("INATIVA");
            s.append('\n');
            s.append("Macro: ").append(CaptureService.macroOn ? "LIGADO" : "DESLIGADO").append('\n');
            s.append("Minijogo: ");
            if (CaptureService.running && CaptureService.detected) {
                s.append("detectado (topo ").append(CaptureService.lastTop)
                        .append(", base ").append(CaptureService.lastBottom)
                        .append(", branco ").append(CaptureService.lastWhite)
                        .append(", coluna ").append(CaptureService.lastColumn).append(')');
            } else s.append("não detectado");
            int[] tp = FishingAccessibilityService.currentTouchPoint();
            if (tp != null) s.append("\nToque em: ").append(tp[0]).append(", ").append(tp[1]).append(" px");
            status.setText(s.toString());
            ui.postDelayed(this, 400);
        }
    };

    @Override protected void onResume() { super.onResume(); ui.post(refresh); }
    @Override protected void onPause() { super.onPause(); ui.removeCallbacks(refresh); }
}
