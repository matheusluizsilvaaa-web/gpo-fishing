package com.sextafeira.gpofishing;

import java.nio.ByteBuffer;

/**
 * Finds the minigame elements in an RGBA_8888 frame.
 * Colors recovered from the original: blue (85,170,255), white (255,255,255),
 * dark gray (25,25,25). Pure Java (no Android classes) so it can be unit-tested.
 *
 * Detection logic is the one that was already in the project:
 *  1. inside the central region, pick the column with most blue pixels;
 *  2. along that column, the longest run of gray/white pixels is the bar
 *     (top..bottom) and the first white pixel is the target line.
 */
public final class FishingScanner {
    /** Small tolerance to absorb rounding; set to 0 for exact matching. */
    private static final int TOL = 3;

    public static final class Result {
        public boolean valid;
        public int top, bottom, white, column;
    }

    private static boolean near(int v, int t) { return Math.abs(v - t) <= TOL; }

    /**
     * @param buf         plane 0 of the image (RGBA byte order)
     * @param rowStride   bytes per row (may be larger than width*4)
     * @param pixelStride bytes per pixel (4 for RGBA_8888)
     */
    public static void scan(ByteBuffer buf, int w, int h, int rowStride, int pixelStride, Result out) {
        out.valid = false;
        int x0 = w / 10, x1 = w * 9 / 10, y0 = h / 5, y1 = h * 4 / 5;

        int bestBlue = 0, mid = -1;
        for (int x = x0; x < x1; x += 2) {
            int n = 0;
            for (int y = y0; y < y1; y += 2) {
                int o = y * rowStride + x * pixelStride;
                if (near(buf.get(o) & 0xFF, 85) && near(buf.get(o + 1) & 0xFF, 170)
                        && near(buf.get(o + 2) & 0xFF, 255)) n++;
            }
            if (n > bestBlue) { bestBlue = n; mid = x; }
        }
        if (mid < 0) return;

        int top = -1, bottom = -1, white = -1, start = -1, best = 0;
        boolean in = false;
        for (int y = y0; y < y1; y++) {
            int o = y * rowStride + mid * pixelStride;
            int r = buf.get(o) & 0xFF, g = buf.get(o + 1) & 0xFF, b = buf.get(o + 2) & 0xFF;
            boolean gray = near(r, 25) && near(g, 25) && near(b, 25);
            boolean wh = near(r, 255) && near(g, 255) && near(b, 255);
            boolean hit = gray || wh;
            if (hit && !in) { start = y; in = true; }
            if (!hit && in) {
                if (y - start > best) { best = y - start; top = start; bottom = y - 1; }
                in = false;
            }
            if (wh && white < 0) white = y;
        }
        if (in && y1 - start > best) { top = start; bottom = y1 - 1; }

        if (top >= 0 && bottom >= top && white >= 0) {
            out.valid = true;
            out.top = top;
            out.bottom = bottom;
            out.white = white;
            out.column = mid;
        }
    }
}
