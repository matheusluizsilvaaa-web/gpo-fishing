package com.sextafeira.gpofishing;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.PixelFormat;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.util.Log;

/**
 * Foreground service that mirrors the screen with MediaProjection, scans every
 * frame and feeds the controller. The touch itself is done by
 * FishingAccessibilityService.
 */
public class CaptureService extends Service {
    private static final String TAG = "GPOFishing";
    private static final String CHANNEL = "capture";
    private static final int NOTIF_ID = 1;

    public static final String ACTION_START = "com.sextafeira.gpofishing.START";
    public static final String ACTION_STOP = "com.sextafeira.gpofishing.STOP";
    public static final String EXTRA_CODE = "code";
    public static final String EXTRA_DATA = "data";

    // ---- state shown on the main screen (written by bg thread, read by UI) ----
    public static volatile boolean running = false;
    public static volatile boolean macroOn = false;
    public static volatile int frameW, frameH;
    public static volatile int fps;
    public static volatile boolean detected;
    public static volatile int lastTop, lastBottom, lastWhite, lastColumn;

    private static volatile boolean resetRequested = false;

    private MediaProjection projection;
    private VirtualDisplay display;
    private ImageReader reader;
    private HandlerThread thread;
    private Handler bg;

    private final TrackController controller = new TrackController();
    private final FishingScanner.Result result = new FishingScanner.Result();
    private int invalidFrames = 0;
    private long lastIdleScanMs = 0, fpsWindowStart = 0;
    private int fpsCount = 0;
    private int curW, curH, curDpi;

    public static void setMacro(boolean on) {
        macroOn = on;
        resetRequested = true;
        if (!on) FishingAccessibilityService.setHold(false);
    }

    @Override public IBinder onBind(Intent i) { return null; }

    @SuppressWarnings("deprecation")
    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) { stopSelf(); return START_NOT_STICKY; }
        if (ACTION_STOP.equals(intent.getAction())) { stopSelf(); return START_NOT_STICKY; }
        if (!ACTION_START.equals(intent.getAction())) return START_NOT_STICKY;
        if (running) return START_NOT_STICKY;

        // Android 14+: the service must already be a mediaProjection foreground
        // service BEFORE getMediaProjection() is called.
        startForeground(NOTIF_ID, buildNotification(),
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);

        int code = intent.getIntExtra(EXTRA_CODE, 0);
        Intent data = intent.getParcelableExtra(EXTRA_DATA);
        if (data == null) { stopSelf(); return START_NOT_STICKY; }

        thread = new HandlerThread("gpo-capture");
        thread.start();
        bg = new Handler(thread.getLooper());

        try {
            MediaProjectionManager mpm =
                    (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
            projection = mpm.getMediaProjection(code, data);
            // Required on Android 14+ before createVirtualDisplay().
            projection.registerCallback(new MediaProjection.Callback() {
                @Override public void onStop() { stopSelf(); }
            }, bg);

            int[] m = ScreenUtil.realMetrics(this);
            curW = m[0]; curH = m[1]; curDpi = m[2];
            reader = newReader(curW, curH);
            display = projection.createVirtualDisplay("gpo-fishing", curW, curH, curDpi,
                    DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                    reader.getSurface(), null, bg);
            running = true;
            fpsWindowStart = System.currentTimeMillis();
            bg.postDelayed(sizeWatcher, 500);
            Log.i(TAG, "capture started " + curW + "x" + curH);
        } catch (Exception e) {
            Log.e(TAG, "capture start failed", e);
            stopSelf();
        }
        return START_NOT_STICKY;
    }

    private ImageReader newReader(int w, int h) {
        ImageReader r = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2);
        r.setOnImageAvailableListener(new ImageReader.OnImageAvailableListener() {
            @Override public void onImageAvailable(ImageReader rd) { onImage(rd); }
        }, bg);
        return r;
    }

    /** Handles rotation: the game is usually landscape, the app is portrait. */
    private final Runnable sizeWatcher = new Runnable() {
        @Override public void run() {
            if (!running) return;
            try {
                int[] m = ScreenUtil.realMetrics(CaptureService.this);
                if (m[0] != curW || m[1] != curH) {
                    curW = m[0]; curH = m[1]; curDpi = m[2];
                    ImageReader old = reader;
                    reader = newReader(curW, curH);
                    display.resize(curW, curH, curDpi);
                    display.setSurface(reader.getSurface());
                    old.close();
                    Log.i(TAG, "screen size changed " + curW + "x" + curH);
                }
            } catch (Exception e) {
                Log.e(TAG, "resize", e);
            }
            bg.postDelayed(this, 500);
        }
    };

    private void onImage(ImageReader r) {
        Image img = null;
        try {
            img = r.acquireLatestImage();
            if (img == null) return;
            long nowMs = System.currentTimeMillis();

            fpsCount++;
            if (nowMs - fpsWindowStart >= 1000) {
                fps = fpsCount; fpsCount = 0; fpsWindowStart = nowMs;
            }

            if (resetRequested) { resetRequested = false; controller.reset(); invalidFrames = 0; }

            // With the macro off, scan only now and then, just to show detection status.
            if (!macroOn && nowMs - lastIdleScanMs < 300) return;
            if (!macroOn) lastIdleScanMs = nowMs;

            Image.Plane p = img.getPlanes()[0];
            frameW = img.getWidth();
            frameH = img.getHeight();
            FishingScanner.scan(p.getBuffer(), frameW, frameH,
                    p.getRowStride(), p.getPixelStride(), result);

            detected = result.valid;
            if (result.valid) {
                lastTop = result.top; lastBottom = result.bottom;
                lastWhite = result.white; lastColumn = result.column;
            }
            if (!macroOn) return;

            if (result.valid) {
                invalidFrames = 0;
                boolean want = controller.update(result.top, result.bottom, result.white,
                        System.nanoTime() / 1e9);
                FishingAccessibilityService.setHold(want);
            } else if (++invalidFrames >= 3) {
                // Minigame is gone: lift the finger and forget the history.
                controller.reset();
                FishingAccessibilityService.setHold(false);
            }
        } catch (Exception e) {
            Log.e(TAG, "frame", e);
        } finally {
            if (img != null) img.close();
        }
    }

    private Notification buildNotification() {
        NotificationManager nm = getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel(CHANNEL, "Captura de tela",
                NotificationManager.IMPORTANCE_LOW));
        PendingIntent pi = PendingIntent.getActivity(this, 0,
                new Intent(this, MainActivity.class), PendingIntent.FLAG_IMMUTABLE);
        return new Notification.Builder(this, CHANNEL)
                .setContentTitle("GPO Fishing Android")
                .setContentText("Captura de tela ativa")
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .setContentIntent(pi)
                .setOngoing(true)
                .build();
    }

    @Override public void onDestroy() {
        running = false;
        macroOn = false;
        detected = false;
        fps = 0;
        FishingAccessibilityService.setHold(false);
        if (bg != null) bg.removeCallbacksAndMessages(null);
        try { if (display != null) display.release(); } catch (Exception ignored) { }
        try { if (reader != null) reader.close(); } catch (Exception ignored) { }
        try { if (projection != null) projection.stop(); } catch (Exception ignored) { }
        if (thread != null) thread.quitSafely();
        super.onDestroy();
    }
}
